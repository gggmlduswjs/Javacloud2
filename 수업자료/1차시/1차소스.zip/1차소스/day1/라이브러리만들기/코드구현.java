package day1.라이브러리만들기;

public class 코드구현  implements   코드{

	@Override
	public void 실행코드() {
		
		
		for( int i=1 ; i<=9; i++) {
			System.out.println( 2*i);
		}
		
	}

}
