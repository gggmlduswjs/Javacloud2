package day1.라이브러리만들기.인터페이스사용;

public class C implements MyRunnable {
	public void run() {
		System.out.println("내정보 출력하기");
	}
}