package day1.라이브러리만들기.인터페이스사용;

class MyLib{


	  public void codeRun( MyRunnable a){
	          a.run();
	  }
 

	}