package day1.라이브러리만들기.인터페이스사용;
class  B implements MyRunnable{ 
    public void  run(){
                 System.out.println("2단");
    }
}