package day1.라이브러리만들기;

public interface 코드 {
	
	 void 실행코드()  ;

}
