package day1.라이브러리만들기.미사용인터페이스;

class MyLib{


	  public void codeRun( A a){
	          a.printStar();
	  }

	  public void codeRun2( B b){
	          b.guguDan();
	  }
	  public void codeRun3( C c){
	          c.printMyInfo();
	  }
	  

	}