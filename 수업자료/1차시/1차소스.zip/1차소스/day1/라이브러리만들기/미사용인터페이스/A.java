package day1.라이브러리만들기.미사용인터페이스;

class  A{
    public void  printStar(){
                 System.out.println("**");
    }
}