package day1.라이브러리만들기.미사용인터페이스;
class  B{
    public void  guguDan(){
                 System.out.println("2단");
    }
}