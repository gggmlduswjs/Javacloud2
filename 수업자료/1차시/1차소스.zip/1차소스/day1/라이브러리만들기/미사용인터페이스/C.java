package day1.라이브러리만들기.미사용인터페이스;

public  class  C{
	public void  printMyInfo()  {
    System.out.println("내정보 출력하기");
 }
}