package day1.generic클래스.printer;

public class Powder  extends Material{
	String content="powder";

	@Override
	public String toString() {
		return "Powder [content=" + content + "]";
	} 
}
