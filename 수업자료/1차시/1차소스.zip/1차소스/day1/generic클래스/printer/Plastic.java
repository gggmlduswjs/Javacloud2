package day1.generic클래스.printer;

public class Plastic  extends Material{
	
	String content="plastic";

	@Override
	public String toString() {
		return "Plastic [content=" + content + "]";
	}
	
	

}
