package day1.generic클래스.printer;

public class Material {

}
