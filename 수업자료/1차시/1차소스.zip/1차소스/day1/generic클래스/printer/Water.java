package day1.generic클래스.printer;

public class Water {	
	String content="water";

	@Override
	public String toString() {
		return "water [content=" + content + "]";
	}

}
