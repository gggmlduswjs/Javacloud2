package day1.오늘의요리사;

interface 일식가능한{ 
    public String  초밥만들기(); 
}

