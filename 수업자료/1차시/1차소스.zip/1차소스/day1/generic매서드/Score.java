package day1.generic매서드;

public class Score {
	String name;

	
	
	
	public Score(String name) {
		super();
		this.name = name;
	}




	@Override
	public String toString() {
		return "Score [name=" + name + "]";
	}
	

}
