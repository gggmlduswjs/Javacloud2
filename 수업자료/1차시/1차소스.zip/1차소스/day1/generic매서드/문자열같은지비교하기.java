package day1.generic매서드;

public class 문자열같은지비교하기 {

	public static void main(String[] args) {
		 
		
		String s1 = "orange";
		String s2 = "orange!";		
		
		
		boolean result  =s1.equals(s2);		
		System.out.println( result);
		 

	}

}
