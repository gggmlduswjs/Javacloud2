package day1.wrapper;

public class Score {

}
