package day1.인터페이스_static_default;

public class A요리사   implements  한식요리가능한 {

	@Override
	public void 구절판만들기() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void 불고기전골만들기() {
		// TODO Auto-generated method stub
		
	}

	
	//default 매서드 오버라이드
	 
	@Override
	public void 김치만두만들기() {		
		System.out.println("나만의 김치만두 만들기");
	}

	 
	 

}
