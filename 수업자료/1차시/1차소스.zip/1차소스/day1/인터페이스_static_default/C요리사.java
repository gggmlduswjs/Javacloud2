package day1.인터페이스_static_default;

public class C요리사   implements 한식요리가능한{

	@Override
	public void 구절판만들기() {
		System.out.println(" 맛있는 구절판 만들기 !");
		
	}

	@Override
	public void 불고기전골만들기() {
		System.out.println(" 정말 맛있는 불고기 만들기  ^^");
		
	}

	 
}
