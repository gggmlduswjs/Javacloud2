package day1.인터페이스_static_default.cookable;

public class 밥요리사 implements Cookable {

    @Override
    public void 재료준비하기() {
        System.out.println("쌀과 물을 준비합니다.");
    }
}
