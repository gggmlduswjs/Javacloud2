package day1.인터페이스_static_default.cookable;

public  class 파스타요리사 implements Cookable {

    @Override
    public void 재료준비하기() {
        System.out.println("파스타 면, 올리브 오일, 마늘을 준비합니다.");
    }
}
