package day4.이름궁합계산기;

public interface MatchCalculator {
	int matchCalculate(String name1, String name2);
}
