package day4prac.실습;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;
import java.util.stream.Collectors;

public class 카페주문프로그램 {

	Cafe cafe;

	public 카페주문프로그램(Cafe cafe) {
		this.cafe = cafe;
	}

	// 메뉴 입력
	public void run() {
		Scanner sc = new Scanner(System.in);

		cafe.selectMenu();

		System.out.print("메뉴를 선택하세요 : ");
		int selectNum = sc.nextInt();

		int price = cafe.selectDrink(selectNum);

		System.out.print("음료 수량 입력해주세요 : ");
		int qty = sc.nextInt();

		System.out.println(selectNum + "번을 고르셨습니다.");
		System.out.println(qty + "잔 수량 선택\n");

		int drinkTotal = cafe.calcPrice(price, qty);
		System.out.println("총 주문 금액 : " + drinkTotal + "원");

	}

	public static void main(String[] args) throws Exception {

		BufferedReader br = new BufferedReader(new FileReader("src/day4prac/실습/config.txt"));

		List<Cafe> cafes = (List<Cafe>) br.lines().map(line -> {
			try {
				Class clazz = Class.forName(line);
				Cafe cafe = (Cafe) clazz.newInstance();
				return cafe;
			} catch (Exception e) {
				throw new RuntimeException(e);
			}
		}).collect(Collectors.toList());

		br.close();

		System.out.println("---등록된 카페 목록---");
		for (Cafe cafe : cafes) {
			System.out.println(cafe.getClass().getSimpleName());
		}

		Scanner sc = new Scanner(System.in);
		System.out.print("\n방문할 카페를 선택하세요 (1 or 2) : ");
		int choice = sc.nextInt();

		Cafe selectedCafe = cafes.get(choice - 1);

		카페주문프로그램 program = new 카페주문프로그램(selectedCafe);
		program.run();

	}

}
