package day4prac.실습;

public class 스타벅스 implements Cafe {

	// 메뉴 선택 화면 출력
	@Override
	public void selectMenu() {
		System.out.println("----------스타벅스 메뉴 선택----------");
		System.out.println("1. 아메리카노   5000원");
		System.out.println("2. 카페라떼   6000원");
		System.out.println("3. 아이스 초코   6500원");
		System.out.println("4. 말차라떼   7000원");
		System.out.println("5. 아샷추   5500원");
		System.out.println("------------------------------------------");
	}

	// 선택 음료 가격 책정
	@Override
	public int selectDrink(int selectNum) {

		if (selectNum == 1) {
			return 5000;
		} else if (selectNum == 2) {
			return 6000;
		} else if (selectNum == 3) {
			return 6500;
		} else if (selectNum == 4) {
			return 7000;
		} else if (selectNum == 5) {
			return 5500;
		} else {
			return 0;
		}

	}

	@Override
	public int calcPrice(int price, int qty) {
		System.out.println("스타벅스 크리스마스 10% 할인 적용");
		return  (int) (price * qty  * 0.9);
	}

}
