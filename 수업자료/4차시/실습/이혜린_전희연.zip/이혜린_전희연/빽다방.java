package day4prac.실습;

public class 빽다방 implements Cafe {

	@Override
	public void selectMenu() {
		System.out.println("----------빽다방 메뉴 선택----------");
		System.out.println("1. 아메리카노   3000원");
		System.out.println("2. 카페라떼   4500원");
		System.out.println("3. 아이스 초코   5000원");
		System.out.println("4. 말차라떼   6000원");
		System.out.println("5. 아샷추   3600원");
		System.out.println("------------------------------------------");

	}

	// 선택 음료 가격 책정
	@Override
	public int selectDrink(int selectNum) {

		if (selectNum == 1) {
			return 3000;
		} else if (selectNum == 2) {
			return 4500;
		} else if (selectNum == 3) {
			return 5000;
		} else if (selectNum == 4) {
			return 6000;
		} else if (selectNum == 5) {
			return 3600;
		} else {
			return 0;
		}

	}
	
	@Override
	public int calcPrice(int price, int qty) {
		System.out.println("빽다방 크리스마스 15% 할인 적용");
		return  (int) (price * qty  * 0.85);
	}

}
