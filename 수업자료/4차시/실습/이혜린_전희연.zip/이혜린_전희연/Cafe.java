package day4prac.실습;

public interface Cafe {
	
	//각 브랜드 메뉴 선택 화면 출력
	public void selectMenu();
	
	//각 브랜드 음료 가격 책정
	public int selectDrink(int selectNum);
	
	//각 브랜드 음료 계산
	public int calcPrice(int price, int qty);

}
