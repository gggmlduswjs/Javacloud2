package day4Prac.실습;

public class Tiger implements Animal{

	@Override
	public void 먹이주기(int foodAmount) {
		// TODO Auto-generated method stub
		System.out.println("호랑이에게 사료 " + foodAmount + "g을 줬습니다!");
	}

	@Override
	public void 놀아주기(String toyName) {
		// TODO Auto-generated method stub
		System.out.println(toyName + "(으)로 호랑이와 놀아주었습니다");
	}

	@Override
	public void 청소하기(int cleanTime) {
		// TODO Auto-generated method stub
		System.out.println("호랑이소굴을 " + cleanTime + "분동안 치웠습니다");
		
	}

	@Override
	public void 재우기(int sleepTime) {
		// TODO Auto-generated method stub
		System.out.println("호랑이가 " + sleepTime + "시간 잠을 잤습니다");
		
	}



}
