package day4Prac.실습;

public class Panda implements Animal{

	@Override
	public void 먹이주기(int foodAmount) {
		// TODO Auto-generated method stub
		System.out.println("판다에게 대나무 " + foodAmount + "kg을 줬습니다!");
	}

	@Override
	public void 놀아주기(String toyName) {
		// TODO Auto-generated method stub
		System.out.println(toyName + "(으)로 판다와 놀아주었습니다");
	}

	@Override
	public void 청소하기(int cleanTime) {
		// TODO Auto-generated method stub
		System.out.println("대나무숲을 " + cleanTime + "분동안 정리했습니다");
	}

	@Override
	public void 재우기(int sleepTime) {
		// TODO Auto-generated method stub
		System.out.println("판다가 " + sleepTime + "시간 잠을 잤습니다");
	}

}
