package day4Prac.실습;

public interface Animal {
	public void 먹이주기(int foodAmount);
	public void 놀아주기(String toyName);
	public void 청소하기(int cleanTime);
	public void 재우기(int sleepTime);
}
