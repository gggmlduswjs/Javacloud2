package day4Prac.실습;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;

public class Zoo {
	
	Animal animal;

	//생성자
	public Zoo(Animal animal) {
		super();
		this.animal = animal;
	}

	
	public void 동물원메뉴() {
		System.out.println("🐯🐼🐬동물원 관리하기🐯🐼🐬");
		System.out.println("1. 먹이주기");
		System.out.println("2. 놀아주기");
		System.out.println("3. 청소하기");
		System.out.println("4. 재우기");
		System.out.println("🐯🐼🐬🐯🐼🐬🐯🐼🐬🐯🐼🐬");
	}
	

	public void 관리하기() {
        Scanner sc = new Scanner(System.in);
        System.out.print("어떤걸 해볼까요~? (1~4): ");
        int choice = sc.nextInt();

        switch (choice) {
            case 1:
            		animal.먹이주기(500);
                break;
            case 2:
            		animal.놀아주기("타이어");
                break;
            case 3:
            		animal.청소하기(50);
                break;
            case 4:
            		animal.재우기(8);
            break;
            default:
                System.out.println("잘못된 입력입니다.");
        }
    }
	
	
	public static void main(String[] args) throws FileNotFoundException, IOException, InstantiationException, IllegalAccessException, ClassNotFoundException {
		
		Properties pp = new Properties();
		pp.load(new FileReader("src/day4Prac/실습/config.txt"));
		String className = pp.getProperty("Animal");
		System.out.println(className);
		
		Class clazz = Class.forName(className);
		Animal animal = (Animal) clazz.newInstance();
		
		Zoo z = new Zoo(animal);
		z.동물원메뉴();
		z.관리하기();
		
	}
	
	

}
