package day4Prac.실습;

public class Dolphin implements Animal{

	@Override
	public void 먹이주기(int foodAmount) {
		// TODO Auto-generated method stub
		System.out.println("돌고레에게 물고기 " + foodAmount + "마리를 줬습니다!");
	}

	@Override
	public void 놀아주기(String toyName) {
		// TODO Auto-generated method stub
		System.out.println(toyName + "(으)로 돌고래와 놀아주었습니다");
	}

	@Override
	public void 청소하기(int cleanTime) {
		// TODO Auto-generated method stub
		System.out.println("아쿠아리움을 " + cleanTime + "시간동안 청소했습니다");
	}

	@Override
	public void 재우기(int sleepTime) {
		// TODO Auto-generated method stub
		System.out.println("돌고래가 " + sleepTime + "시간 잠을 잤습니다");
	}

}
