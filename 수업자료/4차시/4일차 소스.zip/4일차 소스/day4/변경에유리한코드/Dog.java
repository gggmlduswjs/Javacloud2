package day4.변경에유리한코드;

public class Dog  extends Animal {
	
	@Override
	 public void bark() {
		 System.out.println("멍멍");
	 }

}
