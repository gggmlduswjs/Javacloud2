package day4.변경에유리한코드;

public class Animal {	
	 public void bark() {
		 System.out.println("동물이 짖는다");
	 }
}
