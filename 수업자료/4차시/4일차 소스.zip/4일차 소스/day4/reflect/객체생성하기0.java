package day4.reflect;

public class 객체생성하기0 {

	public static void main(String[] args) {
		 
		//0. new를 통한 객체 생성
		Member member = new Member();
		member.printSquare(2);

	}

}
