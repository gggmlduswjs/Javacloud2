package day4.변경에유리한코드실습;

public class Ex1 {

	public static void main(String[] args) {
	 
		
		//
		
		Cat cat = new Cat();
		cat.bark();
		
		
		// dog 변경할 때
		
		Dog dog = new Dog();
		dog.bark();
		
		
	}

}
