package day4.변경에유리한코드실습;

public class Animal {
	
	public void bark() {		
		System.out.println(   "짖는다");
	}

}
