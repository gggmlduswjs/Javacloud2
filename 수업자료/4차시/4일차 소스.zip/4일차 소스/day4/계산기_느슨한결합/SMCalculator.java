package day4.계산기_느슨한결합;

public class SMCalculator  implements Calculator{

	@Override
	public int add(int su1, int su2) {
		// TODO Auto-generated method stub
		return  su1+su2;
	}

}
