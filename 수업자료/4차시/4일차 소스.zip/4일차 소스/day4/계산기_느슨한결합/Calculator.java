package day4.계산기_느슨한결합;

public interface Calculator {	
	int  add ( int su1, int su2);
}
