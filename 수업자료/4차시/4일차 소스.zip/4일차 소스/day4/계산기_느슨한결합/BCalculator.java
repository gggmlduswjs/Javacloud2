package day4.계산기_느슨한결합;

public class BCalculator {	
	public int addB( int num1, int  num2) {		
		return num1+  num2;
	}
}
