package day4.계산기_느슨한결합;

public class ACalculator {

	//두 수를 더한 결과를 반환하는 매서드 
	public int addA( int num1,  int num2) {
		return num1+ num2;		
	}
}
