package day2.lambda;

@FunctionalInterface
public interface HelloInterface {
	 void print();	
	
}
