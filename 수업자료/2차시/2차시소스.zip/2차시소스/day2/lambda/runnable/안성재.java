package day2.lambda.runnable;

public class 안성재   implements Runnable {

	@Override
	public void run() {		 
		System.out.println(" 모수 정식 만들기 ");		
	}

}
