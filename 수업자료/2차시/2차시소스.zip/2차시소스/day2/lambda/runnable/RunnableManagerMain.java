package day2.lambda.runnable;

public class RunnableManagerMain {

	public static void main(String[] args) {
	    RunnableManager manager = new RunnableManager();
        // 초기 등록 없이 메뉴에서 추가 가능
        manager.run();

	}

}
