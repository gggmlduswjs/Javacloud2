package day2.lambda.runnable;


// 


public interface MyRunnable {
	
	void run();

}
