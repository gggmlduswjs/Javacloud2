package day2.lambda.runnable;

public class 김연아  implements Runnable {

	@Override
	public void run() {
		 System.out.println("트리플 러츠–트리플 토룹 콤비네이션   점프하기");
		
	}

}
