package day5.enumEx3;

public enum CharacterState {
	
	정상,
	공격,
	수비,
	죽음

}
