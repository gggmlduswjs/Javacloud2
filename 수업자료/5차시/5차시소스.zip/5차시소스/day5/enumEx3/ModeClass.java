package day5.enumEx3;


//상수로 사용하기
public class ModeClass {
	
	//상수변수
	//상수는 대문자로 작성 
	
	public static final String DARK="DARK";
	public static final String LIGHT="LIGHT";

}
