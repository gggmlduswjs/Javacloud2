package day5.enumEx3;

public class ModeClassMain {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		 String mode  =ModeClass.DARK;
		 mode  = ModeClass.LIGHT;		 
		 
		 
		 
		 // 모드에 다른 문자열에 들어가는것을 방지할 수 없다 
		  
		 mode="Yellow"; 

	}

}


//