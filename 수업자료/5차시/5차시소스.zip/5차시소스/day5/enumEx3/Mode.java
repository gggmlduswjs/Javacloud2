package day5.enumEx3;


// 값은 대문자로 작성
public enum Mode {

	DRARK,
	LIGHT
}
